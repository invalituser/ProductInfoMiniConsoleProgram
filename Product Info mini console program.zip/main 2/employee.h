#ifndef GUARD
#define GUARD
typedef struct{
    int code;
    float price;
    char name[50];
} Product;

void SetProduct(Product *n, int code, float price, char *name);
void printProduct(Product *n);

#endif
