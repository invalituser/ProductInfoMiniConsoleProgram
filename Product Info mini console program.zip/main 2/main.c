#include "employee.h"
int main(){
    Product apple;
    SetProduct( &apple, 234, 12.43, "apple");
    printProduct(&apple);
}