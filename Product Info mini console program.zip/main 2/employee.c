#include <stdio.h>
#include "employee.h"
#include <string.h>

void SetProduct(Product *n, int code, float price, char *name){
    n->code = code;
    n->price = price;
    strcpy(n->name, name);    
}

void printProduct(Product *n){
    printf("CODE: %d\n", n->code);
    printf("PRICE: %.2f\n", n->price);
    printf("PRODUCT NAME: %s\n", n->name);
}

